<?php

$module['language'] = array(

'Security'			=> 'Gestione Sicurezza',
'SecurityMenu'		=> 'Men&ugrave; Principale',
'LogManager'		=> 'Log Manager',
'BannedIP'			=> 'Indirizzi IP bannati',
'Messages'			=> 'Messaggi',
'Priority'			=> 'Priorit&agrave;',
'LogMessage'		=> 'Log Messaggio',
'LastLog'			=> 'Ultimi Log',
'SystemLog'			=> 'Log Sistema',
'AccessLog'			=> 'Log Accessi',
'ErrorsLog'			=> 'Log Errori',
'IPClient'		    => 'IP Client',
'Country'		    => 'Paese',
'Code'				=> 'Codice',
'Date'				=> 'Data',
'BannedTimeout'		=> 'Scadenza divieto',
'enable'		    => 'riabilita',
'LogsNotFound'		=> 'Non ci sono messaggi !',
'BannedIPNotFound'	=> 'Non ci sono IP bannati !',
'IMG:Priority' 		=> '<img src="themes/'.$SUMO['page']['theme'].'/images/modules/security/priority.gif">',
'LogManagerDisabled' => 'Il Log Manager &egrave; disabilitato per questa categoria !'

);

?>