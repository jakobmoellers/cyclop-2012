<?php

$module['language'] = array(

'Security'			=> 'Seguridad',
'SecurityMenu'		=> 'Men&uacute; Principal',
'LogManager'		=> 'Administraci&oacute;n de Logs',
'BannedIP'			=> 'Direcciones IP Bloqueadas',
'Messages'			=> 'Mensajes',
'Priority'			=> 'Prioridad',
'LogMessage'		=> 'Mensajes Log',
'LastLog'			=> '&Uacute;ltimo Log',
'SystemLog'			=> 'Logs del Sistema',
'AccessLog'			=> 'Logs de Acceso',
'ErrorsLog'			=> 'Logs de Errores',
'IPClient'		    => 'Cliente IP',
'Country'		    => 'Pais',
'Code'				=> 'C&oacute;digo',
'Date'				=> 'Fecha',
'BannedTimeout'		=> 'M&aacute;ximo tiempo de bloqueo',
'enable'		    => 'enable',
'LogsNotFound'		=> 'Logs no encontrados !',
'BannedIPNotFound'	=> 'No se han encontrado direcciones IP bloqueadas !',
'IMG:Priority' 		=> '<img src="themes/'.$SUMO['page']['theme'].'/images/modules/security/priority.gif">',
'LogManagerDisabled' => 'Log Manager is disabled for this category !'

);

?>