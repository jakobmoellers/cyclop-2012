<?php

$module['language'] = array(

'Security'			=> 'Security',
'SecurityMenu'		=> 'Main Menu',
'LogManager'		=> 'Log Manager',
'BannedIP'			=> 'Banned IP',
'Messages'			=> 'Messages',
'Priority'			=> 'Priority',
'LogMessage'		=> 'Log Message',
'LastLog'			=> 'Last Log',
'SystemLog'			=> 'System Log',
'AccessLog'			=> 'Access Log',
'ErrorsLog'			=> 'Errors Log',
'IPClient'		    => 'IP Client',
'Country'		    => 'Country',
'Code'				=> 'Code',
'Date'				=> 'Date',
'BannedTimeout'		=> 'Banned timeout',
'enable'		    => 'enable',
'LogsNotFound'		=> 'Logs not found !',
'BannedIPNotFound'	=> 'Banned IP not found !',
'IMG:Priority' 		=> '<img src="themes/'.$SUMO['page']['theme'].'/images/modules/security/priority.gif">',
'LogManagerDisabled' => 'Log Manager is disabled for this category !'

);

?>