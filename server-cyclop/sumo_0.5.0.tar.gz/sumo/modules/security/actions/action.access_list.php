<?php
/**
 * SUMO MODULE: Security | Access Log
 * 
 * @version    0.2.10
 * @link       http://sumoam.sourceforge.net SUMO Access Manager
 * @author     Alberto Basso <albertobasso@users.sourceforge.net>
 * @copyright  Copyright &copy; 2003-2009, Alberto Basso
 * @package    SUMO
 * @category   Console
 */

require SUMO_PATH_MODULE.'/actions/action.loglist.php';

?>