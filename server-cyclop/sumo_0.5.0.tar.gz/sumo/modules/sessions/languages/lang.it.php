<?php

$module['language'] = array(

'ID'			      => 'ID',
'Hostname'			  => 'Nome Host',
'CountryNetwork'      => 'Paese/Rete',
'Connected'	   		  => 'Connesso',
'Expire'	  		  => 'Scadenza',
'RunningSessions'     => 'Sessioni correnti',
'SessionsList'		  => 'Lista Sessioni',
'Client'		      => 'Client',
'Node'				  => 'Nodo',
'WhereIs'			  => 'Dove si trova ?',
'Activity'		      => '&#37; Attivit&agrave;', 
'ActiveSessions'      => 'Sessioni attive',
'NotActiveSessions'   => 'Sessioni non attive',
'ViewUser'			  => 'Visualizza Utente',
'Connections'		  => 'Connessioni',
'ConnectionsList'	  => 'Lista Connessioni',
'Node'		      => 'Nodo',
'IPClient'		      => 'IP Client',
'Requests'	    	  => 'Richieste',
'Connected'			  => 'Connesso',
'ConnectionsNotFound' => 'Non ci sono connessioni'

);

?>