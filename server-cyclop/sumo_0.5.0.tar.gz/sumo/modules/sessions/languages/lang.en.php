<?php

$module['language'] = array(

'ID'			      => 'ID',
'Hostname'			  => 'Hostname',
'CountryNetwork'      => 'Country/Network',
'Connected'	   		  => 'Connected',
'Expire'	  		  => 'Expire',
'RunningSessions'     => 'Running sessions',
'SessionsList'		  => 'Sessions list',
'Client'		      => 'Client',
'Node'				  => 'Node',
'WhereIs'			  => 'Where is ?',
'Activity'		      => '&#37; Activity', 
'ActiveSessions'      => 'Active sessions',
'NotActiveSessions'   => 'Inactive sessions',
'ViewUser'			  => 'View user',
'Connections'		  => 'Connections',
'ConnectionsList'	  => 'Connections list',
'Node'		      => 'Node',
'IPClient'		      => 'Client IP',
'Requests'	    	  => 'Requests',
'Connected'			  => 'Connected',
'ConnectionsNotFound' => 'Connections not found'

);

?>