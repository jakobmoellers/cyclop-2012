<?php

$module['language'] = array(

'ID'			      => 'ID',
'Hostname'			  => 'Nombre de Equipo',
'CountryNetwork'      => 'Pa&iacute;s/Red',
'Connected'	   		  => 'Conectado',
'Expire'	  		  => 'Expira',
'RunningSessions'     => 'Sesiones en marcha',
'SessionsList'		  => 'Listado sesiones',
'Client'		      => 'Cliente',
'Node'				  => 'Nodo',
'WhereIs'			  => 'Donde est&aacute; ?',
'Activity'		      => '&#37; Actividad', 
'ActiveSessions'      => 'Sesiones activas',
'NotActiveSessions'   => 'Sesiones no activas',
'ViewUser'			  => 'Ver usuario',
'Connections'		  => 'Conecxiones',
'ConnectionsList'	  => 'Listado conexiones',
'Node'		      => 'Nodo',
'IPClient'		      => 'Cliente IP',
'Requests'	    	  => 'Peticiones',
'Connected'			  => 'Conectado',
'ConnectionsNotFound' => 'Conexiones no encontradas'

);

?>