<?php
/**
 * SUMO MODULE: Help | Credits
 * 
 * @version    0.3.0
 * @link       http://sumoam.sourceforge.net SUMO Access Manager
 * @author     Alberto Basso <albertobasso@users.sourceforge.net>
 * @copyright  Copyright &copy; 2003-2009, Alberto Basso
 * @package    SUMO
 * @category   Console
 */

$tpl['GET:CreditsDetails'] = $language['CreditsDetails'];

?>