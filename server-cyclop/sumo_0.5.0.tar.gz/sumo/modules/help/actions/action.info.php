<?php
/**
 * SUMO MODULE: Help | Info
 * 
 * @version    0.4.0
 * @link       http://sumoam.sourceforge.net SUMO Access Manager
 * @author     Alberto Basso <albertobasso@users.sourceforge.net>
 * @copyright  Copyright &copy; 2003-2009, Alberto Basso
 * @package    SUMO
 * @category   Console
 */

$tpl['GET:SumoLogo']    = "<img alt='SUMO' src='themes/".$SUMO['page']['theme']."/images/modules/help/logo.jpg'>";
$tpl['GET:InfoDetails'] = $language['InfoDetails'];

?>