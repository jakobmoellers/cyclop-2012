<?php

$module['language'] = array(

'ManPageNotFound' => 'Man page not found! <br><br>&raquo; <MAN:main.0>User Manual Index</MAN>'

);

?>