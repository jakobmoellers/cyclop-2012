<?php

$module['language'] = array(

'ManPageNotFound' => 'P&aacute;gina principal no encontrada! <br><br>&raquo; <MAN:main.0>�ndice Manual Usuario</MAN>'

);

?>