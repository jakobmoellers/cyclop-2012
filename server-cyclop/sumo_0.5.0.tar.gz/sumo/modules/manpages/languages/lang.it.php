<?php

$module['language'] = array(

'ManPageNotFound' => 'Pagina del manuale non trovata! <br><br>&raquo; <MAN:main.0>Indice Manuale</MAN>'

);

?>