<?php

$module['language'] = array(

'ManPageNotFound' => 'Man-page non trouv&eacute;! <br><br>&raquo; <MAN:main.0>Index de manuel d&rsquo;utilisateur</MAN>'

);

?>