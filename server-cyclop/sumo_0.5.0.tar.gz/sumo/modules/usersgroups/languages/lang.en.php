<?php

$module['language'] = array(

'Relationship' 	=> 'Relationship (beta)',

);

?>