<?php

$module['language'] = array(

'Relationship' 	=> 'Relation (beta)',

);

?>