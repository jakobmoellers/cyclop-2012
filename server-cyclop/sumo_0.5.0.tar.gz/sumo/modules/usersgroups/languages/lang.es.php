<?php

$module['language'] = array(

'Relationship' 	=> 'Relaci&oacute;n (beta)',

);

?>