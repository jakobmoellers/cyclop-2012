<?php

$module['language'] = array(

'Relationship' 	=> 'Relazioni (beta)',

);

?>