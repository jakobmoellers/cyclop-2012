<?php

$module['language'] = array(

'GroupName'			=> 'Nome gruppo',
'AccessPoint'   	=> 'AccessPoint',
'UsersList'			=> 'Elenco utenti',
'GroupsList'		=> 'Elenco gruppi',
'AccessPointsList'  => 'Elenco AccessPoints',
'users'				=> 'utenti',
'groups'			=> 'gruppi',
'Diagram'			=> 'Diagramma',
'AllAccessPoints'	=> 'Tutti gli Access Points',

'Group2Users'       => 'Gruppo &gt; Utenti',
'AccessPoint2Users' => 'AccessPoint &gt; Utenti',
'AccessPoint2Group' => 'AccessPoint &gt; Gruppi',
'Group2AccessPoint' => 'Gruppi &gt; AccessPoints',
'User2AccessPoint'  => 'Utente &gt; AccessPoints'

);

?>