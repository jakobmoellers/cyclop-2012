<?php

$module['language'] = array(

'GroupName'			=> 'Group name',
'AccessPoint'   	=> 'AccessPoint',
'UsersList'			=> 'Users list',
'GroupsList'		=> 'Groups list',
'AccessPointsList'  => 'AccessPoints list',
'users'				=> 'users',
'groups'			=> 'groups',
'Diagram'			=> 'Diagram',
'AllAccessPoints'	=> 'All Access points',

'Group2Users'       => 'Users &gt; Group',
'AccessPoint2Users' => 'AccessPoint &gt; Users',
'AccessPoint2Group' => 'AccessPoint &gt; Groups',
'Group2AccessPoint' => 'Groups &gt; AccessPoints',
'User2AccessPoint'  => 'User &gt; AccessPoints'

);

?>