-- Versione MySQL: 5.0.22
-- Versione PHP: 5.1.2
-- 
-- Database: `sumo`
-- 

-- --------------------------------------------------------

-- CREATE DATABASE IF NOT EXISTS `sumo` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
-- USE `sumo`;

-- 
-- Struttura della tabella `sumo_accesspoints`
-- 

CREATE TABLE IF NOT EXISTS `sumo_accesspoints` (
  `id` int(255) unsigned NOT NULL auto_increment,
  `node` int(255) default NULL,
  `path` varchar(255) NOT NULL,
  `name` text,
  `usergroup` text,
  `http_auth` int(1) unsigned NOT NULL default '0',
  `filtering` int(1) unsigned NOT NULL default '1',
  `pwd_encrypt` int(1) unsigned NOT NULL default '1',
  `registration` int(1) NOT NULL default '0',
  `reg_group` varchar(50) default NULL,
  `change_pwd` int(1) NOT NULL default '0',
  `theme` varchar(25) default NULL,
  `created` int(14) unsigned NOT NULL default '0',
  `updated` int(14) unsigned default '0',
  PRIMARY KEY  (`id`),
  KEY `path` (`path`),
  KEY `node` (`node`)
);

-- --------------------------------------------------------

-- 
-- Struttura della tabella `sumo_accesspoints_stats`
-- 

CREATE TABLE IF NOT EXISTS `sumo_accesspoints_stats` (
  `id` int(255) unsigned NOT NULL auto_increment,
  `node` int(255) default NULL,
  `id_page` int(255) unsigned NOT NULL default '0',
  `access` int(255) unsigned NOT NULL default '0',
  `activity` int(255) unsigned NOT NULL default '0',
  `last_login` int(14) unsigned default NULL,
  `updated` int(14) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `id_page` (`id_page`),
  KEY `node` (`node`)
);

INSERT INTO `sumo_accesspoints_stats` (`id`,`node`,`id_page`,`access`,`activity`,`last_login`,`updated`) VALUES (NULL,1,1,0,0,NULL,1249326963);
INSERT INTO `sumo_accesspoints_stats` (`id`,`node`,`id_page`,`access`,`activity`,`last_login`,`updated`) VALUES (NULL,1,2,0,0,NULL,1249326963);

-- --------------------------------------------------------

-- 
-- Struttura della tabella `sumo_banned`
-- 

CREATE TABLE IF NOT EXISTS `sumo_banned` (
  `id` int(255) unsigned NOT NULL auto_increment,
  `ip` varchar(15) NOT NULL default '0',
  `time` int(14) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `ip` (`ip`)
);

-- --------------------------------------------------------

-- 
-- Struttura della tabella `sumo_configs`
-- 

CREATE TABLE IF NOT EXISTS `sumo_configs` (
  `name` varchar(32) NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY  (`name`)
);

-- 
-- Dump dei dati per la tabella `sumo_configs`
-- 

INSERT INTO `sumo_configs` (`name`, `data`) VALUES ('server', '<?xml version="1.0" encoding="iso-8859-1"?><config><console><tip>on</tip></console><database><optimize_hits>10000</optimize_hits></database><server><language>en</language><locale>en_EN</locale><date_format>m/d/Y</date_format><time_format>H:i:s</time_format><admin><name>Administrator</name><email></email></admin><version>0.4.2</version><updated>1249326963</updated><charset>iso-8859-1</charset></server><theme>sumo</theme><iptocountry><enabled>off</enabled></iptocountry><sessions><timeout>1440</timeout><auto_regenerate_id>off</auto_regenerate_id></sessions><connections><timeout>900</timeout></connections><accounts><life>0</life><password><life>0</life></password><registration><enabled>0</enabled><life>24</life><notify><reg>0</reg><unreg>0</unreg></notify></registration></accounts><security><max_login_attempts>10</max_login_attempts><banned_time>300</banned_time><access_violations>1</access_violations></security><logs><life>7</life><system><database><enabled>1</enabled><life>7</life></database><file><enabled>0</enabled><life>7</life><size>256</size></file><email><enabled>0</enabled></email></system><errors><database><enabled>1</enabled><life>7</life></database><file><enabled>0</enabled><life>7</life><size>256</size></file><email><enabled>0</enabled></email></errors><access><database><enabled>1</enabled><life>7</life></database><file><enabled>0</enabled><life>7</life><size>256</size></file><email><enabled>0</enabled></email></access></logs><accesspoints><stats><enabled>0</enabled></stats><def_name>en:Login;it:Login;fr:Login;es:Login</def_name><def_group>sumo</def_group><def_theme>sumo</def_theme></accesspoints></config>');

-- --------------------------------------------------------

-- 
-- Struttura della tabella `sumo_connections`
-- 

CREATE TABLE IF NOT EXISTS `sumo_connections` (
  `id` int(255) unsigned NOT NULL auto_increment,
  `node` varchar(128) NOT NULL,
  `ip` varchar(15) NOT NULL,
  `requests` int(2) NOT NULL default '0',
  `security_string` varchar(128) NOT NULL,
  `time` int(14) unsigned NOT NULL default '0',
  `session_id` varchar(32) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `session_id` (`session_id`)
);

-- --------------------------------------------------------

-- 
-- Struttura della tabella `sumo_datasources`
-- 

CREATE TABLE IF NOT EXISTS `sumo_datasources` (
  `id` int(3) unsigned NOT NULL auto_increment,
  `name` varchar(128) NOT NULL,
  `type` varchar(32) NOT NULL,
  `host` varchar(64) default NULL,
  `port` int(5) unsigned default NULL,
  `username` varchar(32) default NULL,
  `password` varchar(255) default NULL,
  `db_name` varchar(255) default NULL,
  `db_table` varchar(255) default NULL,
  `db_field_user` varchar(255) default NULL,
  `db_field_password` varchar(255) default NULL,
  `enctype` varchar(16) default NULL,
  `ldap_base` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  KEY `host` (`host`)
);

-- 
-- Dump dei dati per la tabella `sumo_datasources`
-- 

INSERT INTO `sumo_datasources` ( `id` , `name` , `type` , `host` , `port` , `username` , `password` , `db_name` , `db_table` , `db_field_user` , `db_field_password` , `enctype`, `ldap_base` )
VALUES (
'1', 'SUMO Access Manager', 'SUMO', 'localhost', NULL , NULL , NULL , NULL , NULL, NULL , NULL , NULL , NULL
);


-- 
-- Struttura della tabella `sumo_groups`
-- 

CREATE TABLE IF NOT EXISTS `sumo_groups` (
  `id` int(255) unsigned NOT NULL auto_increment,
  `usergroup` varchar(50) NOT NULL,
  `description` varchar(255) default NULL,
  `created` int(14) unsigned NOT NULL default '0',
  `updated` int(14) unsigned default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `usergroup` (`usergroup`)
);

-- --------------------------------------------------------

-- 
-- Struttura della tabella `sumo_intranet_ip`
-- 

CREATE TABLE IF NOT EXISTS `sumo_intranet_ip` (
  `id` int(255) unsigned NOT NULL auto_increment,
  `ip` varchar(20) NOT NULL,
  `type` char(1) NOT NULL default 'L',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `ip` (`ip`),
  KEY `type` (`type`)
);

-- 
-- Dump dei dati per la tabella `sumo_intranet_ip`
-- 

INSERT INTO `sumo_intranet_ip` (`id`, `ip`, `type`) VALUES (1, '192.168.0.0/255', 'L'),(2, '127.0.0.1/255', 'L');

-- --------------------------------------------------------

-- 
-- Struttura della tabella `sumo_iptocountry`
-- 

CREATE TABLE IF NOT EXISTS `sumo_iptocountry` (
  `ip_from` int(10) NOT NULL default '0',
  `ip_to` int(10) NOT NULL default '0',
  `country_code2` char(2) NOT NULL,
  `country_code3` char(3) NOT NULL,
  `country_name` varchar(64) NOT NULL,
  KEY `ip_from` (`ip_from`),
  KEY `ip_to` (`ip_to`)
);


-- --------------------------------------------------------

-- 
-- Struttura della tabella `sumo_log_access`
-- 

CREATE TABLE IF NOT EXISTS `sumo_log_access` (
  `id` bigint(255) unsigned NOT NULL auto_increment,
  `priority` int(1) unsigned NOT NULL default '0',
  `code` varchar(7) default NULL,
  `node` varchar(15) NOT NULL default '0',
  `ip` varchar(15) default NULL,
  `country_name` varchar(50) default NULL,
  `message` varchar(255) NOT NULL,
  `time` int(14) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `priority` (`priority`)
);

-- --------------------------------------------------------

-- 
-- Struttura della tabella `sumo_log_errors`
-- 

CREATE TABLE IF NOT EXISTS `sumo_log_errors` (
  `id` bigint(255) unsigned NOT NULL auto_increment,
  `priority` int(1) unsigned NOT NULL default '0',
  `code` varchar(7) default NULL,
  `node` varchar(15) NOT NULL default '0',
  `ip` varchar(15) default NULL,
  `country_name` varchar(50) default NULL,
  `message` varchar(255) NOT NULL,
  `time` int(14) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `priority` (`priority`)
);

-- --------------------------------------------------------

-- 
-- Struttura della tabella `sumo_log_system`
-- 

CREATE TABLE IF NOT EXISTS `sumo_log_system` (
  `id` bigint(255) unsigned NOT NULL auto_increment,
  `priority` int(1) unsigned NOT NULL default '1',
  `code` varchar(7) default NULL,
  `node` varchar(15) NOT NULL,
  `ip` varchar(15) default NULL,
  `country_name` varchar(50) default NULL,
  `message` varchar(255) NOT NULL,
  `time` int(14) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `priority` (`priority`)
);

-- --------------------------------------------------------

-- 
-- Struttura della tabella `sumo_nodes`
-- 

CREATE TABLE IF NOT EXISTS `sumo_nodes` (
  `id` int(255) unsigned NOT NULL auto_increment,
  `active` int(1) unsigned NOT NULL default '0',
  `host` varchar(128) NOT NULL,
  `port` int(5) unsigned NOT NULL default '80',
  `name` varchar(50) NOT NULL,
  `protocol` varchar(5) NOT NULL default 'http',
  `sumo_path` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
);

-- --------------------------------------------------------

-- 
-- Struttura della tabella `sumo_sessions`
-- 

CREATE TABLE IF NOT EXISTS `sumo_sessions` (
  `id` int(255) unsigned NOT NULL auto_increment,
  `node` varchar(32) NOT NULL,
  `id_user` int(255) unsigned NOT NULL default '0',
  `username` varchar(100) NOT NULL,
  `connected` int(14) NOT NULL default '0',
  `expire` int(14) NOT NULL default '0',
  `ip` varchar(15) NOT NULL,
  `hostname` varchar(128) default NULL,
  `country_name` varchar(50) default NULL,
  `url` varchar(128) NOT NULL,
  `client` varchar(255) default NULL,
  `activity` int(4) unsigned default '0',
  `session_id` varchar(32) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `session_id` (`session_id`),
  KEY `time` (`expire`),
  KEY `server` (`node`),
  KEY `id_user` (`id_user`)
);

-- --------------------------------------------------------

-- 
-- Struttura della tabella `sumo_sessions_store`
-- 

CREATE TABLE IF NOT EXISTS `sumo_sessions_store` (
  `sesskey` varchar(64) NOT NULL default '',
  `expiry` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `expireref` varchar(250) default '',
  `created` timestamp NOT NULL default '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL default '0000-00-00 00:00:00',
  `sessdata` longtext,
  PRIMARY KEY  (`sesskey`),
  KEY `sess2_expiry` (`expiry`),
  KEY `sess2_expireref` (`expireref`)
);

-- --------------------------------------------------------

-- 
-- Struttura della tabella `sumo_users`
-- 

CREATE TABLE IF NOT EXISTS `sumo_users` (
  `id` int(255) unsigned NOT NULL auto_increment,
  `username` varchar(100) NOT NULL,
  `firstname` varchar(50) default NULL,
  `lastname` varchar(50) default NULL,
  `password` varchar(40) NOT NULL,
  `active` int(1) NOT NULL default '0',
  `ip` text NOT NULL,
  `usergroup` text NOT NULL,
  `datasource_id` int(3) unsigned default '0',
  `last_login` int(14) default NULL,
  `day_limit` int(3) unsigned default NULL,
  `language` varchar(5) NOT NULL default 'en',
  `email` varchar(100) default NULL,
  `pwd_updated` int(14) unsigned default NULL,
  `created` int(14) unsigned NOT NULL default '0',
  `owner_id` int(255) NOT NULL default '0',
  `modified` int(14) unsigned default NULL,
  `updated` int(14) unsigned default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `login` (`username`),
  KEY `active` (`active`),
  KEY `password` (`password`)
);

-- --------------------------------------------------------

-- 
-- Struttura della tabella `sumo_users_images`
-- 

CREATE TABLE IF NOT EXISTS `sumo_users_images` (
  `id` int(255) unsigned NOT NULL auto_increment,
  `id_user` int(255) NOT NULL default '0',
  `type` varchar(25) NOT NULL,
  `image` blob NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `username` (`id_user`)
);

-- --------------------------------------------------------

-- 
-- Struttura della tabella `sumo_users_temp`
-- 

CREATE TABLE IF NOT EXISTS `sumo_users_temp` (
  `username` varchar(100) NOT NULL,
  `action` tinyint(1) unsigned NOT NULL default '1',
  `email` varchar(100) NOT NULL,
  `language` varchar(5) NOT NULL default 'en',
  `password` varchar(40) NOT NULL,
  `reg_group` varchar(50) NOT NULL,
  `reg_code` varchar(40) NOT NULL,
  `time` int(14) unsigned NOT NULL default '0',
  PRIMARY KEY  (`username`),
  UNIQUE KEY `email` (`email`)
);


-- 
-- Dump dei dati per la tabella `sumo_users`
-- 

INSERT INTO `sumo_users` (`id`, `username`, `firstname`, `lastname`, `password`, `active`, `ip`, `usergroup`, `datasource_id`, `last_login`, `day_limit`, `language`, `email`, `pwd_updated`, `created`, `owner_id`, `modified`, `updated`) VALUES (1, 'sumo', 'Administrator', '', '3d5b3458fe2f6adbd120c86d313f0a3791e19d8a', 1, '', 'sumo:7', 1, 0, NULL, 'en', '', 0, 1249326963, 0, 0, 0);


-- 
-- Dump dei dati per la tabella `sumo_accesspoints`
-- 

INSERT INTO `sumo_accesspoints` (`id`, `node`, `path`, `name`, `usergroup`, `http_auth`, `filtering`, `pwd_encrypt`, `registration`, `reg_group`, `change_pwd`, `theme`, `created`, `updated`) VALUES (1, 1, '/sumo/index.php', 'en:SUMO Console;fr:SUMO Console;it:Pannello di controllo;es:SUMO Consola', 'sumo', 0, 1, 0, 0, 'sumo', 0, 'sumo', 1249326963, 0);
INSERT INTO `sumo_accesspoints` (`id`, `node`, `path`, `name`, `usergroup`, `http_auth`, `filtering`, `pwd_encrypt`, `registration`, `reg_group`, `change_pwd`, `theme`, `created`, `updated`) VALUES (2, 1, '/sumo/examples/frame/login_frame.php', 'en:Example login frame;es:Example login frame;fr:Example login frame;it:Esempio accesso frame', 'sumo', 0, 1, 0, 0, 'sumo', 0, 'iframe', 1249326963, 0);

-- 
-- Dump dei dati per la tabella `sumo_nodes`
-- 

INSERT INTO `sumo_nodes` (`id`, `active`, `host`, `port`, `name`, `protocol`, `sumo_path`) VALUES (1,1,'localhost',80,'Local Node','http','/sumo/');
