
CREATE TABLE "sumo_accesspoints" ( 
"id" integer PRIMARY KEY NOT NULL, 
"node" int(255) default NULL, 
"path" varchar(255) NOT NULL, 
"name" text, "usergroup" text, 
"http_auth" int(1) NOT NULL default '0', 
"filtering" int(1) NOT NULL default '1', 
"pwd_encrypt" int(1) NOT NULL default '1', 
"registration" int(1) NOT NULL default '0', 
"reg_group" varchar(50) default NULL, 
"change_pwd" int(1) NOT NULL default '0', 
"theme" varchar(25) default NULL, 
"created" int(14) NOT NULL default '0', 
"updated" int(14) default '0' );
CREATE INDEX path ON sumo_accesspoints(path);
CREATE INDEX node ON sumo_accesspoints(node);

INSERT INTO sumo_accesspoints (id, node, path, name, usergroup, http_auth, filtering, pwd_encrypt, registration, reg_group, change_pwd, theme, created, updated) VALUES ('1', '1', '/sumo/index.php', 'en:SUMO Console;fr:SUMO Console;it:Pannello di controllo;es:SUMO Consola', 'sumo', '0', '1', '0', '0', 'sumo', '0', 'sumo', 1244622121, '0');
INSERT INTO sumo_accesspoints (id, node, path, name, usergroup, http_auth, filtering, pwd_encrypt, registration, reg_group, change_pwd, theme, created, updated) VALUES ('2', '1', '/sumo/examples/frame/login_frame.php', 'en:Example login frame;es:Example login frame;fr:Example login frame;it:Esempio accesso frame', 'sumo', '0', '1', '0', '0', 'sumo', '0', 'iframe', 1244622121, '0');

CREATE TABLE "sumo_accesspoints_stats" ( 
"id" integer PRIMARY KEY NOT NULL, 
"node" int(255) default NULL, 
"id_page" int(255) NOT NULL default '0', 
"access" int(255) NOT NULL default '0', 
"activity" int(255) NOT NULL default '0', 
"last_login" int(14) default NULL, 
"updated" int(14) NOT NULL default '0' );
CREATE INDEX id_page ON sumo_accesspoints_stats(id_page);
CREATE INDEX node2 ON sumo_accesspoints_stats(node);

INSERT INTO sumo_accesspoints_stats (id, node, id_page, access, activity, last_login, updated) VALUES (NULL, '1', '1', '0', '0', NULL, 1244622121);
INSERT INTO sumo_accesspoints_stats (id, node, id_page, access, activity, last_login, updated) VALUES (NULL, '1', '2', '0', '0', NULL, 1244622121);

CREATE TABLE "sumo_banned" ( 
"id" integer PRIMARY KEY NOT NULL, 
"ip" varchar(15) NOT NULL default '0', 
"time" int(14) NOT NULL default '0' );
CREATE INDEX ip ON sumo_banned(ip);


CREATE TABLE "sumo_configs" ( 
"name" varchar(32) NOT NULL, 
"data" text NOT NULL, 
PRIMARY KEY ("name") );

INSERT INTO sumo_configs (name, data) VALUES ('server', '<?xml version="1.0" encoding="iso-8859-1"?><config><console><tip>on</tip></console><database><optimize_hits>10000</optimize_hits></database><server><language>en</language><locale>en_EN</locale><date_format>m/d/Y</date_format><time_format>H:i:s</time_format><admin><name>Administrator</name><email></email></admin><version>0.4.2</version><updated>1249342312</updated><charset>iso-8859-1</charset></server><theme>sumo</theme><iptocountry><enabled>off</enabled></iptocountry><sessions><timeout>1440</timeout><auto_regenerate_id>off</auto_regenerate_id></sessions><connections><timeout>900</timeout></connections><accounts><life>0</life><password><life>0</life></password><registration><enabled>0</enabled><life>24</life><notify><reg>0</reg><unreg>0</unreg></notify></registration></accounts><security><max_login_attempts>10</max_login_attempts><banned_time>300</banned_time><access_violations>1</access_violations></security><logs><life>7</life><system><database><enabled>1</enabled><life>7</life></database><file><enabled>0</enabled><life>7</life><size>256</size></file><email><enabled>0</enabled></email></system><errors><database><enabled>1</enabled><life>7</life></database><file><enabled>0</enabled><life>7</life><size>256</size></file><email><enabled>0</enabled></email></errors><access><database><enabled>1</enabled><life>7</life></database><file><enabled>0</enabled><life>7</life><size>256</size></file><email><enabled>0</enabled></email></access></logs><accesspoints><stats> n<enabled>0</enabled></stats><def_name>en:Login;it:Login;fr:Login;es:Login</def_name><def_group>sumo</def_group><def_theme>sumo</def_theme></accesspoints></config>');

CREATE TABLE "sumo_connections" ( 
"id" integer PRIMARY KEY NOT NULL, 
"node" varchar(128) NOT NULL, 
"ip" varchar(15) NOT NULL, 
"requests" int(2) NOT NULL default '0', 
"security_string" varchar(128) NOT NULL, 
"time" int(14) NOT NULL default '0', 
"session_id" varchar(32) NOT NULL );
CREATE UNIQUE INDEX session_id ON sumo_connections(session_id);

CREATE TABLE "sumo_datasources" ( 
"id" integer PRIMARY KEY NOT NULL, 
"name" varchar(128) NOT NULL, 
"type" varchar(32) NOT NULL, 
"host" varchar(64) default NULL, 
"port" int(5) default NULL, 
"username" varchar(32) default NULL, 
"password" varchar(255) default NULL, 
"db_name" varchar(255) default NULL, 
"db_table" varchar(255) default NULL, 
"db_field_user" varchar(255) default NULL, 
"db_field_password" varchar(255) default NULL, 
"enctype" varchar(16) default NULL,
"ldap_base" varchar(255) default NULL );
CREATE INDEX host ON sumo_datasources ( host );

INSERT INTO sumo_datasources (id, name, type, host, port, username, password, db_name, db_table, db_field_user, db_field_password, enctype, ldap_base) VALUES ('1', 'SUMO Access Manager', 'SUMO', 'localhost', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

CREATE TABLE "sumo_groups" ( 
"id" integer PRIMARY KEY NOT NULL, 
"usergroup" varchar(50) NOT NULL, 
"description" varchar(255) default NULL, 
"created" int(14) NOT NULL default '0', 
"updated" int(14) default '0' );
CREATE UNIQUE INDEX "usergroup" ON sumo_groups ( "usergroup" );

CREATE TABLE "sumo_intranet_ip" ( 
"id" integer PRIMARY KEY NOT NULL, 
"ip" varchar(20) NOT NULL, 
"type" char(1) NOT NULL default 'L' );
CREATE UNIQUE INDEX "ip2" ON sumo_intranet_ip ( "ip" );

INSERT INTO sumo_intranet_ip (id, ip, type) VALUES ('1', '192.168.0.0/255', 'L');
INSERT INTO sumo_intranet_ip (id, ip, type) VALUES ('2', '127.0.0.1/255', 'L');

CREATE TABLE "sumo_iptocountry" ( 
"ip_from" int(10) NOT NULL default '0', 
"ip_to" int(10) NOT NULL default '0', 
"country_code2" char(2) NOT NULL, 
"country_code3" char(3) NOT NULL, 
"country_name" varchar(64) NOT NULL );
CREATE INDEX "ip_from" ON sumo_iptocountry ( "ip_from" );

CREATE TABLE "sumo_log_access" ( 
"id" INTEGER PRIMARY KEY NOT NULL, 
"priority" int(1) NOT NULL default '0', 
"code" varchar(7) default NULL, 
"node" varchar(15) NOT NULL default '0', 
"ip" varchar(15) default NULL, 
"country_name" varchar(50) default NULL, 
"message" varchar(255) NOT NULL, 
"time" int(14) NOT NULL default '0' );
CREATE INDEX "priority" ON sumo_log_access ( "priority" );

CREATE TABLE "sumo_log_errors" ( 
"id" INTEGER PRIMARY KEY NOT NULL, 
"priority" int(1) NOT NULL default '1', 
"code" varchar(7) default NULL, 
"node" varchar(15) NOT NULL, 
"ip" varchar(15) default NULL, 
"country_name" varchar(50) default NULL, 
"message" varchar(255) NOT NULL, 
"time" int(14) NOT NULL default '0' );
CREATE INDEX "priority2" ON sumo_log_errors ( "priority" );

CREATE TABLE "sumo_log_system" ( 
"id" INTEGER PRIMARY KEY NOT NULL, 
"priority" int(1) NOT NULL default '1', 
"code" varchar(7) default NULL, 
"node" varchar(15) NOT NULL, 
"ip" varchar(15) default NULL, 
"country_name" varchar(50) default NULL, 
"message" varchar(255) NOT NULL, 
"time" int(14) NOT NULL default '0' );
CREATE INDEX "priority3" ON sumo_log_system ( "priority" );

CREATE TABLE "sumo_nodes" ( 
"id" integer PRIMARY KEY NOT NULL, 
"active" int(1) NOT NULL default '0', 
"host" varchar(128) NOT NULL, 
"port" int(5) NOT NULL default '80', 
"name" varchar(50) NOT NULL, 
"protocol" varchar(5) NOT NULL default 'http', 
"sumo_path" varchar(255) NOT NULL );

INSERT INTO sumo_nodes (id, active, host, port, name, protocol, sumo_path) VALUES (1,1,'localhost',80,'Local Node','http','/sumo/');



CREATE TABLE "sumo_sessions" ( 
"id" integer PRIMARY KEY NOT NULL, 
"node" varchar(32) NOT NULL, 
"id_user" int(255) NOT NULL default '0', 
"username" varchar(100) NOT NULL, 
"connected" int(14) NOT NULL default '0', 
"expire" int(14) NOT NULL default '0', 
"ip" varchar(15) NOT NULL, 
"hostname" varchar(128) default NULL, 
"country_name" varchar(50) default NULL, 
"url" varchar(128) NOT NULL, 
"client" varchar(255) default NULL, 
"activity" int(4) default '0', 
"session_id" varchar(32) NOT NULL );
CREATE INDEX "session_id2" ON sumo_sessions ( "session_id" );

CREATE TABLE "sumo_sessions_store" ( 
"sesskey" VARCHAR( 64 ) PRIMARY KEY NOT NULL, 
"expiry" TIMESTAMP NOT NULL , 
"expireref" VARCHAR( 250 ) DEFAULT '', 
"created" TIMESTAMP NOT NULL , 
"modified" TIMESTAMP NOT NULL , 
"sessdata" TEXT DEFAULT '' );
CREATE INDEX "sess2_expiry" on sumo_sessions_store ( "expiry" );
CREATE INDEX "sess2_expireref" on sumo_sessions_store ( "expireref" );

CREATE TABLE "sumo_users" ( 
"id" integer PRIMARY KEY NOT NULL, 
"username" varchar(100) NOT NULL, 
"firstname" varchar(50) default NULL, 
"lastname" varchar(50) default NULL, 
"password" varchar(40) NOT NULL, 
"active" int(1) NOT NULL default '0', 
"ip" text NOT NULL, 
"usergroup" text NOT NULL, 
"datasource_id" int(3) default '0', 
"last_login" int(14) default NULL, 
"day_limit" int(3) default NULL, 
"language" varchar(5) NOT NULL default 'en', 
"email" varchar(100) default NULL, 
"pwd_updated" int(14) default NULL, 
"created" int(14) NOT NULL default '0', 
"owner_id" int(255) NOT NULL default '0', 
"modified" int(14) default NULL, 
"updated" int(14) default NULL );
CREATE INDEX active on sumo_users ( active );
CREATE INDEX password on sumo_users ( password );
CREATE UNIQUE INDEX login on sumo_users ( username );

INSERT INTO sumo_users (id, username, firstname, lastname, password, active, ip, usergroup, datasource_id, last_login, day_limit, language, email, pwd_updated, created, owner_id, modified, updated) VALUES ('1', 'sumo', 'Administrator', NULL, '3d5b3458fe2f6adbd120c86d313f0a3791e19d8a', '1', '', 'sumo:7', '1', '0', NULL, 'en', NULL, '0', 1244622121, '0', '0', '0');

CREATE TABLE "sumo_users_images" ( 
"id" integer PRIMARY KEY NOT NULL, 
"id_user" int(255) NOT NULL default '0', 
"type" varchar(25) NOT NULL, 
"image" blob NOT NULL );
CREATE UNIQUE INDEX username on sumo_users_images ( id_user );

CREATE TABLE "sumo_users_temp" ( 
"username" varchar(100) PRIMARY KEY NOT NULL, 
"action" tinyint(1) NOT NULL default '1', 
"email" varchar(100) NOT NULL, 
"language" varchar(5) NOT NULL default 'en', 
"password" varchar(40) NOT NULL, 
"reg_group" varchar(50) NOT NULL, 
"reg_code" varchar(40) NOT NULL, 
"time" int(14) NOT NULL default '0' );
CREATE UNIQUE INDEX email on sumo_users_temp ( email );
