--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;
SET search_path = public, pg_catalog;

CREATE SEQUENCE sumo_accesspoints_id_seq
    START WITH 3
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

SELECT pg_catalog.setval('sumo_accesspoints_id_seq', 3, false);

SET default_tablespace = '';
SET default_with_oids = false;


CREATE TABLE sumo_accesspoints (
    id integer DEFAULT nextval('sumo_accesspoints_id_seq'::regclass) NOT NULL,
    node integer,
    path character varying(255),
    name text,
    usergroup text,
    http_auth integer DEFAULT 0,
    filtering integer DEFAULT 1,
    pwd_encrypt integer DEFAULT 1,
    registration integer DEFAULT 0,
    reg_group character varying(50),
    change_pwd integer DEFAULT 0,
    theme character varying(25),
    created integer DEFAULT 0,
    updated integer DEFAULT 0
);

CREATE SEQUENCE sumo_accesspoints_stats_id_seq
    START WITH 3
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

SELECT pg_catalog.setval('sumo_accesspoints_stats_id_seq', 3, false);

CREATE TABLE sumo_accesspoints_stats (
    id integer DEFAULT nextval('sumo_accesspoints_stats_id_seq'::regclass) NOT NULL,
    node integer,
    id_page integer DEFAULT 0,
    access integer DEFAULT 0,
    activity integer DEFAULT 0,
    last_login integer,
    updated integer DEFAULT 0
);

CREATE SEQUENCE sumo_banned_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

SELECT pg_catalog.setval('sumo_banned_id_seq', 1, false);

CREATE TABLE sumo_banned (
    id integer DEFAULT nextval('sumo_banned_id_seq'::regclass) NOT NULL,
    ip character varying(15) DEFAULT 0,
    "time" integer DEFAULT 0
);

CREATE TABLE sumo_configs (
    name character varying(32) NOT NULL,
    data text
);

CREATE SEQUENCE sumo_connections_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

SELECT pg_catalog.setval('sumo_connections_id_seq', 16, true);

CREATE TABLE sumo_connections (
    id integer DEFAULT nextval('sumo_connections_id_seq'::regclass) NOT NULL,
    node character varying(128),
    ip character varying(15),
    requests integer DEFAULT 0,
    security_string character varying(128),
    "time" integer DEFAULT 0,
    session_id character varying(32)
);

CREATE SEQUENCE sumo_datasources_id_seq
    START WITH 2
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

SELECT pg_catalog.setval('sumo_datasources_id_seq', 2, false);

CREATE TABLE sumo_datasources (
    id integer DEFAULT nextval('sumo_datasources_id_seq'::regclass) NOT NULL,
    name character varying(128),
    type character varying(32),
    host character varying(64),
    port integer,
    username character varying(32),
    password character varying(255),
    db_name character varying(255),
    db_table character varying(255),
    db_field_user character varying(255),
    db_field_password character varying(255),
    enctype character varying(16),
    ldap_base character varying(255)
);

CREATE SEQUENCE sumo_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

SELECT pg_catalog.setval('sumo_groups_id_seq', 1, false);

CREATE TABLE sumo_groups (
    id integer DEFAULT nextval('sumo_groups_id_seq'::regclass) NOT NULL,
    usergroup character varying(50),
    description character varying(255),
    created integer DEFAULT 0,
    updated integer DEFAULT 0
);

CREATE SEQUENCE sumo_intranet_ip_id_seq
    START WITH 3
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

SELECT pg_catalog.setval('sumo_intranet_ip_id_seq', 3, false);

CREATE TABLE sumo_intranet_ip (
    id integer DEFAULT nextval('sumo_intranet_ip_id_seq'::regclass) NOT NULL,
    ip character varying(20),
    type character(1) DEFAULT 'L'::bpchar
);

CREATE TABLE sumo_iptocountry (
    ip_from bigint DEFAULT 0,
    ip_to bigint DEFAULT 0,
    country_code2 character(2),
    country_code3 character(3),
    country_name character varying(64)
);

CREATE SEQUENCE sumo_log_access_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

SELECT pg_catalog.setval('sumo_log_access_id_seq', 1, true);

CREATE TABLE sumo_log_access (
    id bigint DEFAULT nextval('sumo_log_access_id_seq'::regclass) NOT NULL,
    priority integer DEFAULT 0,
    code character varying(7),
    node character varying(15) DEFAULT 0,
    ip character varying(15),
    country_name character varying(50),
    message character varying(255),
    "time" integer DEFAULT 0
);

CREATE SEQUENCE sumo_log_errors_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


SELECT pg_catalog.setval('sumo_log_errors_id_seq', 1, true);

CREATE TABLE sumo_log_errors (
    id bigint DEFAULT nextval('sumo_log_errors_id_seq'::regclass) NOT NULL,
    priority integer DEFAULT 0,
    code character varying(7),
    node character varying(15) DEFAULT 0,
    ip character varying(15),
    country_name character varying(50),
    message character varying(255),
    "time" integer DEFAULT 0
);

CREATE SEQUENCE sumo_log_system_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

SELECT pg_catalog.setval('sumo_log_system_id_seq', 1, false);

CREATE TABLE sumo_log_system (
    id bigint DEFAULT nextval('sumo_log_system_id_seq'::regclass) NOT NULL,
    priority integer DEFAULT 1,
    code character varying(7),
    node character varying(15),
    ip character varying(15),
    country_name character varying(50),
    message character varying(255),
    "time" integer DEFAULT 0
);


CREATE SEQUENCE sumo_nodes_id_seq
    START WITH 3
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


SELECT pg_catalog.setval('sumo_nodes_id_seq', 3, false);

CREATE TABLE sumo_nodes (
    id integer DEFAULT nextval('sumo_nodes_id_seq'::regclass) NOT NULL,
    active integer DEFAULT 0,
    host character varying(128),
    port integer DEFAULT 80,
    name character varying(50),
    protocol character varying(5) DEFAULT 'http'::character varying,
    sumo_path character varying(255)
);

CREATE SEQUENCE sumo_sessions_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


SELECT pg_catalog.setval('sumo_sessions_id_seq', 1, true);

CREATE TABLE sumo_sessions (
    id integer DEFAULT nextval('sumo_sessions_id_seq'::regclass) NOT NULL,
    node character varying(32),
    id_user integer DEFAULT 0,
    username character varying(100),
    connected integer DEFAULT 0,
    expire integer DEFAULT 0,
    ip character varying(15),
    hostname character varying(128),
    country_name character varying(50),
    url character varying(128),
    client character varying(255),
    activity integer DEFAULT 0,
    session_id character varying(32)
);

CREATE TABLE sumo_sessions_store (
    sesskey character varying(64) NOT NULL,
    expiry timestamp without time zone DEFAULT now(),
    expireref character varying(250),
    created timestamp without time zone,
    modified timestamp without time zone,
    sessdata text
);

CREATE SEQUENCE sumo_users_id_seq
    START WITH 2
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


SELECT pg_catalog.setval('sumo_users_id_seq', 2, false);

CREATE TABLE sumo_users (
    id integer DEFAULT nextval('sumo_users_id_seq'::regclass) NOT NULL,
    username character varying(100),
    firstname character varying(50),
    lastname character varying(50),
    password character varying(40),
    active integer DEFAULT 0,
    ip text,
    usergroup text,
    datasource_id integer DEFAULT 0,
    last_login integer,
    day_limit integer,
    language character varying(5) DEFAULT 'en'::character varying,
    email character varying(100),
    pwd_updated integer,
    created integer DEFAULT 0,
    owner_id integer DEFAULT 0,
    modified integer,
    updated integer
);

CREATE SEQUENCE sumo_users_images_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;
    
SELECT pg_catalog.setval('sumo_users_images_id_seq', 1, false);

CREATE TABLE sumo_users_images (
    id integer DEFAULT nextval('sumo_users_images_id_seq'::regclass) NOT NULL,
    id_user integer DEFAULT 0,
    type character varying(25),
    image bytea NOT NULL
);


CREATE TABLE sumo_users_temp (
    username character varying(100) NOT NULL,
    action integer DEFAULT 1,
    email character varying(100),
    language character varying(5) DEFAULT 'en'::character varying,
    password character varying(40),
    reg_group character varying(50),
    reg_code character varying(40),
    "time" integer DEFAULT 0
);

--


INSERT INTO sumo_accesspoints_stats (id,node,id_page,access,activity,last_login,updated) VALUES (1,1,1,0,0,NULL,1249326963);
INSERT INTO sumo_accesspoints_stats (id,node,id_page,access,activity,last_login,updated) VALUES (2,1,2,0,0,NULL,1249326963);


INSERT INTO sumo_datasources ( id , "name" , type , host , port , username , password , db_name , db_table , db_field_user , db_field_password , enctype, ldap_base )
VALUES (
'1', 'SUMO Access Manager', 'SUMO', 'localhost', NULL , NULL , NULL , NULL , NULL, NULL , NULL , NULL , NULL
);

INSERT INTO sumo_intranet_ip (id, ip, type) VALUES (1, '192.168.0.0/255', 'L'),(2, '127.0.0.1/255', 'L');
INSERT INTO sumo_users (id, username, firstname, lastname, password, active, ip, usergroup, datasource_id, last_login, day_limit, language, email, pwd_updated, created, owner_id, modified, updated) VALUES (1, 'sumo', 'Administrator', '', '3d5b3458fe2f6adbd120c86d313f0a3791e19d8a', 1, '', 'sumo:7', 1, 0, NULL, 'en', '', 0, 1249326963, 0, 0, 0);

INSERT INTO sumo_accesspoints (id, node, path, "name", usergroup, http_auth, filtering, pwd_encrypt, registration, reg_group, change_pwd, theme, created, updated) VALUES (1, 1, '/sumo/index.php', 'en:SUMO Console;fr:SUMO Console;it:Pannello di controllo;es:SUMO Consola', 'sumo', 0, 1, 0, 0, 'sumo', 0, 'sumo', 1249326963, 0);
INSERT INTO sumo_accesspoints (id, node, path, "name", usergroup, http_auth, filtering, pwd_encrypt, registration, reg_group, change_pwd, theme, created, updated) VALUES (2, 1, '/sumo/examples/frame/login_frame.php', 'en:Example login frame;es:Example login frame;fr:Example login frame;it:Esempio accesso frame', 'sumo', 0, 1, 0, 0, 'sumo', 0, 'iframe', 1249326963, 0);

INSERT INTO sumo_nodes (id, active, host, port, "name", protocol, sumo_path) VALUES (1,1,'localhost',80,'Local Node','http','/sumo/');

INSERT INTO sumo_configs ("name", data) VALUES ('server','<?xml version="1.0" encoding="iso-8859-1"?><config><console><tip>on</tip></console><database><optimize_hits>10000</optimize_hits></database><server><language>en</language><locale>en_EN</locale><date_format>m/d/Y</date_format><time_format>H:i:s</time_format><admin><name>Administrator</name><email></email></admin><version>0.4.2</version><updated>1249326963</updated><charset>iso-8859-1</charset></server><theme>sumo</theme><iptocountry><enabled>off</enabled></iptocountry><sessions><timeout>1440</timeout><auto_regenerate_id>off</auto_regenerate_id></sessions><connections><timeout>900</timeout></connections><accounts><life>0</life><password><life>0</life></password><registration><enabled>0</enabled><life>24</life><notify><reg>0</reg><unreg>0</unreg></notify></registration></accounts><security><max_login_attempts>10</max_login_attempts><banned_time>300</banned_time><access_violations>1</access_violations></security><logs><life>7</life><system><database><enabled>1</enabled><life>7</life></database><file><enabled>0</enabled><life>7</life><size>256</size></file><email><enabled>0</enabled></email></system><errors><database><enabled>1</enabled><life>7</life></database><file><enabled>0</enabled><life>7</life><size>256</size></file><email><enabled>0</enabled></email></errors><access><database><enabled>1</enabled><life>7</life></database><file><enabled>0</enabled><life>7</life><size>256</size></file><email><enabled>0</enabled></email></access></logs><accesspoints><stats><enabled>0</enabled></stats><def_name>en:Login;it:Login;fr:Login;es:Login</def_name><def_group>sumo</def_group><def_theme>sumo</def_theme></accesspoints></config>');

--

ALTER TABLE ONLY sumo_accesspoints
    ADD CONSTRAINT sumo_accesspoints_pkey PRIMARY KEY (id);

ALTER TABLE ONLY sumo_accesspoints_stats
    ADD CONSTRAINT sumo_accesspoints_stats_pkey PRIMARY KEY (id);

ALTER TABLE ONLY sumo_banned
    ADD CONSTRAINT sumo_banned_pkey PRIMARY KEY (id);

ALTER TABLE ONLY sumo_configs
    ADD CONSTRAINT sumo_configs_pkey PRIMARY KEY (name);

ALTER TABLE ONLY sumo_connections
    ADD CONSTRAINT sumo_connections_pkey PRIMARY KEY (id);

ALTER TABLE ONLY sumo_connections
    ADD CONSTRAINT sumo_connections_uk UNIQUE (session_id);

ALTER TABLE ONLY sumo_datasources
    ADD CONSTRAINT sumo_datasources_pkey PRIMARY KEY (id);

ALTER TABLE ONLY sumo_groups
    ADD CONSTRAINT sumo_groups_pkey PRIMARY KEY (id);

ALTER TABLE ONLY sumo_groups
    ADD CONSTRAINT sumo_groups_uk UNIQUE (usergroup);

ALTER TABLE ONLY sumo_intranet_ip
    ADD CONSTRAINT sumo_intranet_ip_pkey PRIMARY KEY (id);

ALTER TABLE ONLY sumo_intranet_ip
    ADD CONSTRAINT sumo_intranet_ip_uk UNIQUE (ip);

ALTER TABLE ONLY sumo_log_access
    ADD CONSTRAINT sumo_log_access_pkey PRIMARY KEY (id);

ALTER TABLE ONLY sumo_log_errors
    ADD CONSTRAINT sumo_log_errors_pkey PRIMARY KEY (id);

ALTER TABLE ONLY sumo_log_system
    ADD CONSTRAINT sumo_log_system_pkey PRIMARY KEY (id);

ALTER TABLE ONLY sumo_nodes
    ADD CONSTRAINT sumo_nodes_pkey PRIMARY KEY (id);

ALTER TABLE ONLY sumo_sessions
    ADD CONSTRAINT sumo_sessions_pkey PRIMARY KEY (id);

ALTER TABLE ONLY sumo_sessions_store
    ADD CONSTRAINT sumo_sessions_store_pkey PRIMARY KEY (sesskey);

ALTER TABLE ONLY sumo_users_images
    ADD CONSTRAINT sumo_users_images_pkey PRIMARY KEY (id);

ALTER TABLE ONLY sumo_users_images
    ADD CONSTRAINT sumo_users_images_uk UNIQUE (id_user);

ALTER TABLE ONLY sumo_users
    ADD CONSTRAINT sumo_users_pkey PRIMARY KEY (id);

ALTER TABLE ONLY sumo_users_temp
    ADD CONSTRAINT sumo_users_temp_pkey PRIMARY KEY (username);

ALTER TABLE ONLY sumo_users_temp
    ADD CONSTRAINT sumo_users_temp_uk UNIQUE (email);

ALTER TABLE ONLY sumo_users
    ADD CONSTRAINT sumo_users_uk UNIQUE (username);

--

CREATE INDEX sumo_accesspoints_node_idx ON sumo_accesspoints USING btree (node);
CREATE INDEX sumo_accesspoints_path_idx ON sumo_accesspoints USING btree (path);
CREATE INDEX sumo_accesspoints_stats_id_page_idx ON sumo_accesspoints_stats USING btree (id_page);
CREATE INDEX sumo_accesspoints_stats_node_idx ON sumo_accesspoints_stats USING btree (node);
CREATE INDEX sumo_datasources_host_idx ON sumo_datasources USING btree (host);
CREATE INDEX sumo_intranet_ip_type_idx ON sumo_intranet_ip USING btree (type);
CREATE INDEX sumo_iptocountry_ip_from_idx ON sumo_iptocountry USING btree (ip_from);
CREATE INDEX sumo_iptocountry_ip_to_idx ON sumo_iptocountry USING btree (ip_to);
CREATE INDEX sumo_log_access_priority_idx ON sumo_log_access USING btree (priority);
CREATE INDEX sumo_log_errors_priority_idx ON sumo_log_errors USING btree (priority);
CREATE INDEX sumo_log_system_priority_idx ON sumo_log_system USING btree (priority);
CREATE INDEX sumo_sessions_expire_idx ON sumo_sessions USING btree (expire);
CREATE INDEX sumo_sessions_id_user_idx ON sumo_sessions USING btree (id_user);
CREATE INDEX sumo_sessions_node_idx ON sumo_sessions USING btree (node);
CREATE INDEX sumo_sessions_session_id_idx ON sumo_sessions USING btree (session_id);
CREATE INDEX sumo_sessions_store_expireref_idx ON sumo_sessions_store USING btree (expireref);
CREATE INDEX sumo_sessions_store_expiry_idx ON sumo_sessions_store USING btree (expiry);
CREATE INDEX sumo_users_active_idx ON sumo_users USING btree (active);
CREATE INDEX sumo_users_password_idx ON sumo_users USING btree (password);


REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;

--
-- PostgreSQL database dump complete
--