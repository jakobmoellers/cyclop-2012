<!--
if (document.all)
document.body.onmousedown=new Function("if (event.button==2||event.button==3)alert('Please enter User and Password.')")
//-->