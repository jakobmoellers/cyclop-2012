<!--
	document.SumoRegistration.reg_name.value="";
	document.SumoRegistration.reg_email.value="";
    document.SumoRegistration.reg_name.focus();
-->