<?php


// Your page content
echo "My content... <hr>";


	echo "<ul>
			<li><a href='page1.php'>Page 1</a></li>
			<li><a href='page2.php'>Page 2</a></li>
		  </ul>";

?>