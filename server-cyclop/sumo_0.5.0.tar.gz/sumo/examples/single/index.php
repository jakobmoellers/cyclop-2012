<?php

/**
 * Set your correct path to sumo.php
 */
require "../../sumo.php";

// Your page content
echo "My content... <hr>";

// Logout link
echo "<a href='?sumo_action=logout'>Logout</a>";

?>